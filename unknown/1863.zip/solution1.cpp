#include <stdio.h>
#include <stdarg.h>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <string>
#include <set>

#ifdef ONLINE_JUDGE
#pragma comment (linker, "/STACK:16000000")
#endif

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a,b) memset(a, b, sizeof(a))

typedef std::pair<int, int> pii;
typedef long long ll;

void dbg(const char * fmt, ...)
{
	#ifndef ONLINE_JUDGE
		va_list args;
		va_start(args, fmt);
		vfprintf(stdout, fmt, args);
		va_end(args);
	#endif
}

int ar[1<<20];
int d[40];
int cnt = 0;

int main()
{
	#ifndef ONLINE_JUDGE
		freopen("input.txt", "r", stdin);
		freopen("output.txt", "w", stdout);
	#endif
	int n, n0, k;
	scanf("%d%d%d", &n, &n0, &k);
	for(int i = 0; i < k; i++)
		scanf("%d", &d[i]);
	int l1 = std::min(k, 20), l2 = k - l1;
	for(int msk = 0; msk < (1<<l1); msk++)
	{
		int x = n0;
		bool good = true;
		for(int j = 0; j < l1; j++)
		{
			if (msk & (1<<j))
				x += d[j];
			else
				x -= d[j];
			if (x < 0 || x > n)
				good = false;
		}
		if (good)
			ar[cnt++] = x;		
	}
	std::sort(ar, ar+cnt);
	cnt = std::unique(ar, ar+cnt) - ar;

	int curd;
	int min = n, max = 0;
	for(int msk = 0; msk < (1<<l2); msk++)
	{
		int l = 0, r = n, shift = 0;
		bool good = true;
		for(int j = 0; j < l2; j++)
		{			
			if (msk & (1<<j))
				curd = d[l1 + j];
			else
				curd = -d[l1 + j];
			l += curd;
			l = std::max(l, 0);
			r += curd;
			r = std::min(r, n);
			shift += curd;
			if (l > r)
				good = false;
		}
		if (good)
		{
			int * pos = std::lower_bound(ar, ar+cnt, l - shift);
			if (pos < ar + cnt && *pos <= r - shift)
				min = std::min(min, *pos + shift);
			pos = std::upper_bound(ar, ar+cnt, r - shift) - 1;
			if (pos >= ar && *pos >= l - shift)
				max = std::max(max, *pos + shift);
		}
	}
	printf("%d %d\n", min, max);


	return 0;
}
