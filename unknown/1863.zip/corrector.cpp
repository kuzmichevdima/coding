#include "../strict.h"

const int MAXN = 1000000000, MAXK = 40;

Input in;

int main() {
	int n = in.readInt(1, MAXN);
	in.readSpace();
	in.readInt(0, n);
	in.readSpace();
	int k = in.readInt(1, MAXK);
	in.readEoln();
	in.readIntVector(k, 1, n);
	in.readEoln();
	in.readEof();
	return 0;
}
