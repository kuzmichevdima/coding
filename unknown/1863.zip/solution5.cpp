#include <stdio.h>
#include <vector>
#include <utility>

typedef std::vector<int> VI;
typedef std::pair<int, int> Pii;
typedef std::vector<Pii> VPii;

int H, h;

const int MN = 40;
int n, n2;
int A[MN];

VI merge (const VI& v, int d) {
	VI res;
	int im = 0;
	int ip = 0;
	int n = (int)v.size ();
	while (im < n || ip < n) {
		while (im < n && v[im] - d < 0)
			++im;
		while (ip < n && v[ip] + d > H)
			++ip;
		if (im == n && ip < n)
			res.push_back (v[ip++] + d);
		else if (ip == n && im < n)
			res.push_back (v[im++] - d);
		else if (im < n && ip < n) {
			int xm = v[im] - d;
			int xp = v[ip] + d;
			int x = xm < xp ? xm : xp;
			res.push_back (x);
			if (x == xm)
				++im;
			if (x == xp)
				++ip;
		}
	}
	return res;
}

inline void put (VPii& v, Pii p, int d) {
	p.first += d;
	p.second += d;
	if (p.first < 0)
		p.first = 0;
	if (p.second > H)
		p.second = H;
	if (p.first > p.second)
		return;
	if (v.empty () || p.first > v.back ().second + 1)
		v.push_back (p);
	else if (v.back ().second < p.second)
		v.back ().second = p.second;
}

VPii merge (const VPii& v, int d) {
	VPii res;
	int im = 0;
	int ip = 0;
	int n = (int)v.size ();
	while (im < n || ip < n) {
		if (ip == n || im < n && v[im].first - d < v[ip].first + d)
			put (res, v[im++], -d);
		else
			put (res, v[ip++], +d);
	}
	return res;
}

bool merge (const VI& v, const VPii& r) {
	int iv = 0;
	int nv = (int)v.size ();
	int ir = 0;
	int nr = (int)r.size ();
	while (iv < nv && ir < nr) {
		if (v[iv] < r[ir].first)
			++iv;
		else if (v[iv] > r[ir].second)
			++ir;
		else
			return true;
	}
	return false;
}

inline VPii f (int h0, int h1) {
	VPii res (size_t (1), Pii (h0, h1));
	for (int i = n - 1; i > n2; --i)
		res = merge (res, A[i]);
	return res;
}

int main () {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	scanf ("%d%d%d", &H, &h, &n);
	for (int i = 0; i < n; ++i)
		scanf ("%d", &A[i]);
	n2 = n / 2;
	VI v (size_t (1), h);
	for (int i = 0; i <= n2; ++i)
		v = merge (v, A[i]);
	if (!merge (v, f (0, H))) {
		printf ("Impossible\n");
	} else {
		int l, r;
		l = 0, r = H;
		while (l < r) {
			int m = (l + r) / 2;
			if (merge (v, f (0, m)))
				r = m;
			else
				l = m + 1;
		}
		int L = l;
		l = 0, r = H;
		while (l < r) {
			int m = (l + r + 1) / 2;
			if (merge (v, f (m, H)))
				l = m;
			else
				r = m - 1;
		}
		int R = l;
		printf ("%d %d\n", L, R);
	}
	return 0;
}
