import java.io.*;
import java.util.*;
import java.math.*;

public class elevator_dd
{
	StringTokenizer in;
	BufferedReader br;

	String next() throws IOException
	{
		while(!in.hasMoreTokens())
		{
			String line = br.readLine();
			if (line == null)
				return null;
			in = new StringTokenizer(line);
		}		
		return in.nextToken();
	}
	int readInt() throws IOException
	{
		return Integer.parseInt(next());
	}

	void run() throws IOException
	{
		boolean oj = System.getProperty("ONLINE_JUDGE") != null;
		Reader reader = oj ? new InputStreamReader(System.in) : new FileReader("input.txt");
		Writer writer = oj ? new OutputStreamWriter(System.out) : new FileWriter("output.txt");
		br = new BufferedReader(reader);
		in = new StringTokenizer("");
		PrintWriter out = new PrintWriter(writer);
		int n, n0, k;
		n = readInt();
		n0 = readInt();
		k = readInt();
		int [] d = new int[k];
		for(int i = 0; i < k; i++)
			d[i] = readInt();
		int l1 = Math.min(k, 20), l2 = k - l1;
		int [] ar = new int[1 << l1];
		int cnt = 0;
		for(int msk = 0; msk < (1<<l1); msk++)
		{
			int x = n0;
			boolean good = true;
			for(int j = 0; j < l1; j++)
			{
				if ((msk & (1<<j)) != 0)
					x += d[j];
				else
					x -= d[j];
				if (x < 0 || x > n)
					good = false;
			}
			if (good)
				ar[cnt++] = x;		
		}
		Arrays.sort(ar, 0, cnt);

		int curd;
		int min = n, max = 0;
		for(int msk = 0; msk < (1<<l2); msk++)
		{
			int l = 0, r = n, shift = 0;
			boolean good = true;
			for(int j = 0; j < l2; j++)
			{			
				if ((msk & (1<<j)) != 0)
					curd = d[l1 + j];
				else
					curd = -d[l1 + j];
				l += curd;
				l = Math.max(l, 0);
				r += curd;
				r = Math.min(r, n);
				shift += curd;
				if (l > r)
					good = false;
			}
			if (good)
			{
				int pos = Arrays.binarySearch(ar, 0, cnt, l - shift);
				if (pos < 0)
					pos = -1 - pos;
				if (pos < cnt && ar[pos] <= r - shift)
					min = Math.min(min, ar[pos] + shift);
				pos = Arrays.binarySearch(ar, 0, cnt, r - shift);
				if (pos < 0)
					pos = -2 - pos;
				if (pos >= 0 && ar[pos] >= l - shift)
					max = Math.max(max, ar[pos] + shift);
			}
		}
		out.println(min + " " + max);

		out.flush();
	}

	public static void main(String [] args) throws IOException
	{
		new elevator_dd().run();
	}
}
