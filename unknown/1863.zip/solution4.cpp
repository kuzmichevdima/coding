#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

const int MAX = 1 << 21;

int points[MAX];
int mvs[100];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n, k, f;
	cin >> n >> f >> k;
	for (int i = 0; i < k; i++)
	{
		cin >> mvs[i];
	}
	int pcnt = 0;
	int fwd = k/2, bwd = k - fwd;
	for (int i = 0; i < (1 << fwd); i++)
	{
		bool allow = true;
		int cur = f;
		for (int j = 0; j < fwd; j++)
		{
			if ((i >> j) % 2)
				cur += mvs[j];
			else
				cur -= mvs[j];
			if (cur < 0 || cur > n)
			{
				allow = false;
				break;
			}
		} 
		if (allow)
			points[pcnt++] = cur;
	}
	points[pcnt++] = n+1;
	points[pcnt++] = -1;
	sort(points, points + pcnt);
	int _min = n+1, _max = -1;
	for (int i = 0; i < (1 << bwd); i++)
	{
		int left = 0, right = n, dif = 0;
		for (int j = 0; j < bwd; j++)
		{
			int mv = mvs[k-1-j];
			if ((i >> j) % 2)
				mv = -mv;
			dif += mv;
			left = max(0, left + mv);
			right = min(n, right + mv);
			if (left > right)
				break;
		}
		int l = -1, r = pcnt - 1;
		while (r - l > 1)
		{
			int m = (r + l) / 2;
			if (points[m] >= left)
				r = m;
			else
				l = m;
		}
		if (left <= points[r] && points[r] <= right)
		{
			_min = min(_min, points[r] - dif);
		}
		l = 0, r = pcnt;
		while (r - l > 1)
		{
			int m = (r + l) / 2;
			if (points[m] <= right)
				l = m;
			else
				r = m;
		}
		if (left <= points[l] && points[l] <= right)
		{
			_max = max(_max, points[l] - dif);
		}
	}
	if (_max == -1)
	{
		cout << "Impossible";
		return 0;
	}
	cout << _min << ' ' << _max << endl;
	return 0;
}
