import java.io.*;
import java.util.*;

public class elevator_as {
	Scanner in;
	PrintWriter out;
	
	int n;
	int k;
	int[] shifts;
	int curMin, curMax;
	TreeSet<Integer> firstHalf;
	
	void addAnswer(int l, int r, int tot) {
	    SortedSet<Integer> middle = firstHalf.subSet(l, r + 1);
	    if (middle.isEmpty()) return;
	    curMin = Math.min(curMin, middle.first() + tot);
	    curMax = Math.max(curMax, middle.last() + tot);
	}
	
	void gen(int l, int r, int tot, int dir, int shiftNum, int lastShift) {
	    if (shiftNum == lastShift) {
	        if (dir == 1) {
	            firstHalf.add(l);
	        } else {
    	        addAnswer(l, r, tot);
    	    }
	        return;
	    }
	    int d = shifts[shiftNum];
	    if (r - d >= 0) {
	        gen(Math.max(0, l - d), r - d, tot + d, dir, shiftNum + dir, lastShift);
	    }
	    if (l + d <= n) {
	        gen(l + d, Math.min(n, r + d), tot - d, dir, shiftNum + dir, lastShift);
	    }
	}
	
	public void run() throws IOException {
		boolean oj = System.getProperty("ONLINE_JUDGE") != null;
		in = oj ? new Scanner(System.in) : new Scanner(new File("input.txt"));
		out = oj ? new PrintWriter(System.out) :
		        new PrintWriter(new File("output.txt"));
		
		n = in.nextInt();
        int s = in.nextInt();
        k = in.nextInt();
        shifts = new int[k];
        for (int i = 0; i < k; i++) {
            shifts[i] = in.nextInt();
        }
        curMin = n;
        curMax = 0;
        firstHalf = new TreeSet<Integer>();
        gen(s, s, 0, 1, 0, k/2);
        gen(0, n, 0, -1, k - 1, k/2 - 1);
        
        out.println(curMin + " " + curMax);		
		out.flush();
	}
	
	public static void main(String[] args) throws IOException {
		new elevator_as().run();
	}
}
